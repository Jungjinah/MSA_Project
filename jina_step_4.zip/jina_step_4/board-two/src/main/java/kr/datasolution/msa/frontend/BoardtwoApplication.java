package kr.datasolution.msa.frontend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication // EnableEurekaClient를 사용해도 무방 but, 이건 유레카 라이브러리만 지원
@EnableDiscoveryClient  // EnableDiscoveryClient는 유레카 외에도 주키퍼, 컨설 등이 존재
public class BoardtwoApplication {

    public static void main(String[] args) {
        SpringApplication.run(BoardtwoApplication.class, args);
    }

}
